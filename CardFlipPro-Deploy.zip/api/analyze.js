// This serverless function acts as a proxy to Ximilar's API
// It keeps your API token secure (not exposed in browser)

export default async function handler(req, res) {
  // Only allow POST requests
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // =====================================================
  // PUT YOUR XIMILAR API TOKEN HERE
  // =====================================================
  const XIMILAR_API_TOKEN = process.env.XIMILAR_API_TOKEN || 'YOUR_TOKEN_HERE';
  // =====================================================

  try {
    const { imageBase64, action } = req.body;

    if (!imageBase64) {
      return res.status(400).json({ error: 'No image provided' });
    }

    // Determine which endpoint to call
    const endpoint = action === 'grade' 
      ? 'https://api.ximilar.com/collectibles/v2/grade'
      : 'https://api.ximilar.com/collectibles/v2/sport_id';

    // Call Ximilar API
    const ximilarResponse = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Token ${XIMILAR_API_TOKEN}`,
      },
      body: JSON.stringify({
        records: [{ _base64: imageBase64 }],
        pricing: true,      // Include pricing data
        slab_id: true,      // Identify graded slabs
        magic_ai: true,     // Use advanced AI for better matching
      }),
    });

    if (!ximilarResponse.ok) {
      const errorText = await ximilarResponse.text();
      console.error('Ximilar API Error:', errorText);
      return res.status(ximilarResponse.status).json({ 
        error: 'Ximilar API error',
        details: errorText 
      });
    }

    const data = await ximilarResponse.json();
    return res.status(200).json(data);

  } catch (error) {
    console.error('Server error:', error);
    return res.status(500).json({ error: 'Server error', message: error.message });
  }
}
